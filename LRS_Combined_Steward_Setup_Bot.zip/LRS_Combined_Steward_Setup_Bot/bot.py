import os
import urllib.parse
import discord
from discord.ext import commands
from discord import app_commands
from dotenv import load_dotenv

load_dotenv()


# ============================================================
# TOKEN
# ============================================================

TOKEN = os.getenv("DISCORD_TOKEN")

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN environment variable is missing.")


# ============================================================
# BOT SETUP
# ============================================================

intents = discord.Intents.default()
intents.guilds = True
intents.messages = True
intents.message_content = True

bot = commands.Bot(
    command_prefix="!",
    intents=intents
)


# ============================================================
# RACE DIRECTOR APP DETECTION
# ============================================================

RACE_DIRECTOR_NAMES = {"racedirectorapp", "racedirector"}
DEFENCE_SUBMITTED_TRIGGER = "defence submitted!"
NO_DEFENCE_TRIGGER = "no defence evidence was submitted"
STEWARD_CALL_TRIGGER = "stewards"
VERDICT_TRIGGER = "/verdict"
FINALIZE_VERDICT_TRIGGER = "finalize your verdict"


def get_message_search_text(message: discord.Message) -> str:
    """Combine normal message text and embed text for reliable detection."""
    parts = [message.content or ""]

    for embed in message.embeds:
        if embed.title:
            parts.append(embed.title)
        if embed.description:
            parts.append(embed.description)

        for field in embed.fields:
            if field.name:
                parts.append(field.name)
            if field.value:
                parts.append(field.value)

        if embed.footer and embed.footer.text:
            parts.append(embed.footer.text)

        if embed.author and embed.author.name:
            parts.append(embed.author.name)

    return "\n".join(parts).lower()


def is_race_director_sender(message: discord.Message) -> bool:
    """Recognise RaceDirectorAPP whether it arrives as a bot or webhook."""
    author_name = str(getattr(message.author, "name", "")).lower()
    display_name = str(getattr(message.author, "display_name", "")).lower()

    return any(
        name in author_name or name in display_name
        for name in RACE_DIRECTOR_NAMES
    )


def is_race_director_steward_call(message: discord.Message) -> bool:
    """Detect the RaceDirectorAPP defence-submitted steward call."""
    if not message.guild:
        return False

    if not is_race_director_sender(message):
        return False

    search_text = get_message_search_text(message)

    standard_defence_call = (
        DEFENCE_SUBMITTED_TRIGGER in search_text
        and STEWARD_CALL_TRIGGER in search_text
        and VERDICT_TRIGGER in search_text
    )

    no_defence_call = (
        NO_DEFENCE_TRIGGER in search_text
        and STEWARD_CALL_TRIGGER in search_text
        and FINALIZE_VERDICT_TRIGGER in search_text
    )

    return standard_defence_call or no_defence_call


# ============================================================
# LRS PENALTY RULES
# ============================================================

PENALTIES = {
    "minor_collision": {
        "name": "Minor Avoidable Collision",
        "points": 1,
        "penalty": 3,
        "options": [3],
    },

    "moderate_collision": {
        "name": "Moderately Avoidable Collision",
        "points": 2,
        "penalty": 5,
        "options": [5, 10],
    },

    "major_collision": {
        "name": "Major Avoidable Collision",
        "points": 3,
        "penalty": 10,
        "options": [10, 15],
    },

    "quali_block": {
        "name": "Quali Block",
        "points": None,
        "penalty": "Qualifying Ban at Next Event",
        "options": None,
    },

    "pit_cut": {
        "name": "Pit Entry / Exit Cut",
        "points": None,
        "penalty": 5,
        "options": [5],
    },

    "track_reset": {
        "name": "Track Reset",
        "points": None,
        "penalty": "Qualifying Ban at Next Event",
        "options": None,
    },
}


# ============================================================
# STEWARD VOTE TRACKING
# ============================================================

# Votes are stored per Discord ticket/channel while the bot is running.
# A steward submitting again in the same ticket replaces their previous vote.
STEWARD_VOTES = {}

# Stores the most recent public steward-result message in each ticket/channel.
# When another vote is cast, the old result message is deleted and replaced.
LATEST_RESULT_MESSAGES = {}


def record_steward_vote(channel_id, user, offence_name, points, penalty):
    channel_votes = STEWARD_VOTES.setdefault(channel_id, {})

    channel_votes[user.id] = {
        "user_id": user.id,
        "display_name": getattr(user, "display_name", str(user)),
        "offence_name": offence_name,
        "points": points,
        "penalty": penalty,
    }

    return channel_votes


def build_vote_summary(channel_votes):
    if not channel_votes:
        return "No steward votes recorded yet.", "No majority yet."

    lines = []
    counts = {}

    for vote in channel_votes.values():
        penalty_text = format_penalty(vote["penalty"])
        lines.append(
            f"<@{vote['user_id']}> — "
            f"**{vote['offence_name']}** — **{penalty_text}**"
        )

        key = (
            vote["offence_name"],
            vote["points"],
            str(vote["penalty"])
        )
        counts[key] = counts.get(key, 0) + 1

    top_count = max(counts.values())
    leaders = [
        key for key, count in counts.items()
        if count == top_count
    ]

    if len(leaders) == 1:
        offence_name, points, penalty = leaders[0]

        # Restore numeric formatting where possible.
        try:
            numeric_penalty = float(penalty)
            if numeric_penalty.is_integer():
                penalty = int(numeric_penalty)
            else:
                penalty = numeric_penalty
        except (TypeError, ValueError):
            pass

        majority = (
            f"**{offence_name}** — "
            f"**{format_penalty(penalty)}** "
            f"({top_count} vote{'s' if top_count != 1 else ''})"
        )
    else:
        majority = (
            f"**Tied vote** — {top_count} "
            f"vote{'s' if top_count != 1 else ''} each."
        )

    return "\n".join(lines), majority


# ============================================================
# HELPERS
# ============================================================

def format_penalty(penalty):

    if isinstance(penalty, (int, float)):

        if float(penalty).is_integer():
            return f"{int(penalty)} Seconds"

        return f"{penalty:g} Seconds"

    return str(penalty)


def format_points(points):

    if points is None:
        return "N/A"

    return f"{points} PP"


def collision_recommendation(damage, time_loss):

    damage = damage.lower()

    # Classify damage severity.
    damage_level = {
        "small": 1,
        "moderate": 2,
        "severe": 3,
    }.get(damage, 1)

    # Classify time-loss severity.
    if time_loss > 5:
        time_level = 3
    elif time_loss >= 1:
        time_level = 2
    else:
        time_level = 1

    # Use whichever factor gives the more serious classification.
    severity_level = max(damage_level, time_level)

    if severity_level == 3:
        return "🔴 MAJOR", PENALTIES["major_collision"]

    if severity_level == 2:
        return "🟠 MODERATE", PENALTIES["moderate_collision"]

    return "🟢 MINOR", PENALTIES["minor_collision"]


# ============================================================
# POST RESULT VIEW
# ============================================================

class PostResultView(discord.ui.View):

    def __init__(
        self,
        offence_name,
        points,
        penalty
    ):

        super().__init__(timeout=300)

        self.offence_name = offence_name
        self.points = points
        self.penalty = penalty

    @discord.ui.button(
        label="Post Result",
        style=discord.ButtonStyle.success
    )
    async def post_result(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        points_text = format_points(
            self.points
        )

        penalty_text = format_penalty(
            self.penalty
        )

        channel_votes = record_steward_vote(
            interaction.channel.id,
            interaction.user,
            self.offence_name,
            self.points,
            self.penalty
        )

        vote_summary, majority = build_vote_summary(
            channel_votes
        )

        embed = discord.Embed(
            title="⚖️ LRS STEWARD RESULT",
            description=(
                "**My Recommendation for the Following "
                "Incident is:**"
            )
        )

        embed.add_field(
            name="Steward",
            value=interaction.user.mention,
            inline=False
        )

        embed.add_field(
            name="Offence",
            value=self.offence_name,
            inline=False
        )

        embed.add_field(
            name="Licence Points",
            value=points_text,
            inline=True
        )

        embed.add_field(
            name="Additional Penalty",
            value=penalty_text,
            inline=True
        )

        embed.add_field(
            name="Steward Votes in This Ticket",
            value=vote_summary[:1024],
            inline=False
        )

        embed.add_field(
            name="Current Majority Recommendation",
            value=majority,
            inline=False
        )

        embed.add_field(
            name="Status",
            value="**STEWARD VOTE RECORDED**",
            inline=False
        )

        embed.set_footer(
            text=(
                "A steward may submit again to replace their "
                "previous vote in this ticket."
            )
        )

        try:

            # Delete the previous public result in this ticket before
            # posting the newly updated vote summary.
            previous_message = LATEST_RESULT_MESSAGES.get(
                interaction.channel.id
            )

            if previous_message is not None:
                try:
                    await previous_message.delete()
                except discord.NotFound:
                    pass
                except discord.Forbidden:
                    print(
                        "Unable to delete previous steward result: "
                        "missing Manage Messages permission."
                    )
                except Exception as e:
                    print(
                        f"Error deleting previous steward result: {e}"
                    )

            new_message = await interaction.channel.send(
                embed=embed
            )

            LATEST_RESULT_MESSAGES[
                interaction.channel.id
            ] = new_message

            await interaction.response.send_message(
                (
                    "✅ Your steward vote has been recorded. "
                    "The previous result was replaced with the updated vote summary."
                ),
                ephemeral=True
            )

            self.clear_items()

        except discord.Forbidden:

            await interaction.response.send_message(
                "❌ I do not have permission to post in this channel.",
                ephemeral=True
            )

        except Exception as e:

            print(
                f"Error posting steward result: {e}"
            )

            if not interaction.response.is_done():

                await interaction.response.send_message(
                    "❌ Unable to post the steward result.",
                    ephemeral=True
                )


# ============================================================
# EDIT PENALTY MODAL
# ============================================================

class EditPenaltyModal(discord.ui.Modal):

    def __init__(
        self,
        offence_name,
        points,
        current_penalty
    ):

        super().__init__(
            title="Edit Time Penalty"
        )

        self.offence_name = offence_name
        self.points = points

        self.penalty_input = discord.ui.TextInput(
            label="Additional Penalty (seconds)",
            placeholder="Example: 7",
            default=str(current_penalty),
            required=True,
            max_length=8
        )

        self.add_item(
            self.penalty_input
        )

    async def on_submit(
        self,
        interaction: discord.Interaction
    ):

        try:

            penalty = float(
                self.penalty_input.value
            )

            if penalty < 0:
                raise ValueError

        except ValueError:

            await interaction.response.send_message(
                "⚠️ Please enter a valid number of seconds.",
                ephemeral=True
            )

            return

        await interaction.response.send_message(
            "Penalty updated. You can now post the recommendation.",
            ephemeral=True
        )

        await interaction.followup.send(
            embed=discord.Embed(
                title="⚖️ LRS PENALTY RECOMMENDATION",
                description=(
                    "Review the recommendation below "
                    "before posting it."
                )
            ),
            view=PostResultView(
                self.offence_name,
                self.points,
                penalty
            ),
            ephemeral=True
        )


# ============================================================
# PENALTY EDIT VIEW
# ============================================================

class PenaltyEditView(discord.ui.View):

    def __init__(
        self,
        offence_name,
        points,
        current_penalty,
        options=None
    ):

        super().__init__(
            timeout=300
        )

        self.offence_name = offence_name
        self.points = points
        self.current_penalty = current_penalty
        self.options = options or []

        for value in self.options:

            button = discord.ui.Button(
                label=f"{value}s",
                style=discord.ButtonStyle.primary
            )

            async def callback(
                interaction,
                value=value
            ):

                await self.show_penalty(
                    interaction,
                    value
                )

            button.callback = callback

            self.add_item(
                button
            )

        edit_button = discord.ui.Button(
            label="Edit Penalty",
            style=discord.ButtonStyle.secondary
        )

        async def edit_callback(
            interaction
        ):

            await interaction.response.send_modal(
                EditPenaltyModal(
                    self.offence_name,
                    self.points,
                    self.current_penalty
                )
            )

        edit_button.callback = edit_callback

        self.add_item(
            edit_button
        )

    async def show_penalty(
        self,
        interaction,
        penalty
    ):

        points_text = format_points(
            self.points
        )

        penalty_text = format_penalty(
            penalty
        )

        embed = discord.Embed(
            title="⚖️ LRS PENALTY RECOMMENDATION",
            description=(
                "Review the recommendation below."
            )
        )

        embed.add_field(
            name="Offence",
            value=self.offence_name,
            inline=False
        )

        embed.add_field(
            name="Licence Points",
            value=points_text,
            inline=True
        )

        embed.add_field(
            name="Additional Penalty",
            value=penalty_text,
            inline=True
        )

        embed.add_field(
            name="Steward Action",
            value=(
                "Use **Edit Penalty** if required, "
                "then select **Post Result**."
            ),
            inline=False
        )

        embed.set_footer(
            text=(
                "Recommendation only • "
                "Final decision remains with LRS stewards"
            )
        )

        await interaction.response.send_message(
            embed=embed,
            view=PostResultView(
                self.offence_name,
                self.points,
                penalty
            ),
            ephemeral=True
        )


# ============================================================
# COLLISION DAMAGE VIEW
# ============================================================

class CollisionView(discord.ui.View):

    def __init__(self):

        super().__init__(
            timeout=300
        )

    @discord.ui.button(
        label="Small Damage",
        style=discord.ButtonStyle.success
    )
    async def small(
        self,
        interaction,
        button
    ):

        await self.ask_time(
            interaction,
            "small"
        )

    @discord.ui.button(
        label="Moderate Damage",
        style=discord.ButtonStyle.primary
    )
    async def moderate(
        self,
        interaction,
        button
    ):

        await self.ask_time(
            interaction,
            "moderate"
        )

    @discord.ui.button(
        label="Severe Damage",
        style=discord.ButtonStyle.danger
    )
    async def severe(
        self,
        interaction,
        button
    ):

        await self.ask_time(
            interaction,
            "severe"
        )

    async def ask_time(
        self,
        interaction,
        damage
    ):

        await interaction.response.send_message(
            "Select the estimated time loss:",
            view=TimeLossView(damage),
            ephemeral=True
        )


# ============================================================
# TIME LOSS VIEW
# ============================================================

class TimeLossView(discord.ui.View):

    def __init__(
        self,
        damage
    ):

        super().__init__(
            timeout=300
        )

        self.damage = damage

    async def result(
        self,
        interaction,
        seconds
    ):

        result = collision_recommendation(
            self.damage,
            seconds
        )

        if result is None:

            await interaction.response.send_message(
                (
                    "⚠️ **NO AUTOMATIC CLASSIFICATION**\n\n"
                    f"Damage: **{self.damage.title()}**\n"
                    f"Time loss: **{seconds:g}s**\n\n"
                    "The damage/time-loss combination does not "
                    "exactly match the current LRS thresholds.\n\n"
                    "⚠️ **STEWARD REVIEW REQUIRED**"
                ),
                ephemeral=True
            )

            return

        severity, rule = result

        options = rule["options"]

        option_text = " / ".join(
            f"{value}s"
            for value in options
        )

        embed = discord.Embed(
            title="⚖️ LRS PENALTY RECOMMENDATION",
            description=(
                "Review the recommended penalty below."
            )
        )

        embed.add_field(
            name="Classification",
            value=severity,
            inline=False
        )

        embed.add_field(
            name="Offence",
            value=rule["name"],
            inline=False
        )

        embed.add_field(
            name="Licence Points",
            value=format_points(
                rule["points"]
            ),
            inline=True
        )

        embed.add_field(
            name="Recommended Additional Penalty",
            value=option_text,
            inline=True
        )

        embed.add_field(
            name="Steward Action",
            value=(
                "Choose a penalty, edit it if necessary, "
                "then select **Post Result**."
            ),
            inline=False
        )

        embed.set_footer(
            text=(
                "Recommendation only • "
                "Final decision remains with LRS stewards"
            )
        )

        await interaction.response.send_message(
            embed=embed,
            view=PenaltyEditView(
                offence_name=rule["name"],
                points=rule["points"],
                current_penalty=rule["penalty"],
                options=options
            ),
            ephemeral=True
        )

    @discord.ui.button(
        label="Under 1 sec",
        style=discord.ButtonStyle.success
    )
    async def under_one(
        self,
        interaction,
        button
    ):

        await self.result(
            interaction,
            0.5
        )

    @discord.ui.button(
        label="1–5 sec",
        style=discord.ButtonStyle.primary
    )
    async def one_to_five(
        self,
        interaction,
        button
    ):

        await self.result(
            interaction,
            3
        )

    @discord.ui.button(
        label="Over 5 sec",
        style=discord.ButtonStyle.danger
    )
    async def over_five(
        self,
        interaction,
        button
    ):

        await self.result(
            interaction,
            6
        )


# ============================================================
# OFFENCE VIEW
# ============================================================

class OffenceView(discord.ui.View):

    def __init__(self):

        super().__init__(
            timeout=300
        )

    async def show_rule(
        self,
        interaction,
        key
    ):

        rule = PENALTIES[key]

        points_text = format_points(
            rule["points"]
        )

        # Quali Block and Track Reset
        # have a qualifying ban.
        if isinstance(
            rule["penalty"],
            str
        ):

            embed = discord.Embed(
                title="⚖️ LRS PENALTY RECOMMENDATION",
                description=(
                    "Review the recommendation below."
                )
            )

            embed.add_field(
                name="Offence",
                value=rule["name"],
                inline=False
            )

            embed.add_field(
                name="Licence Points",
                value=points_text,
                inline=True
            )

            embed.add_field(
                name="Additional Penalty",
                value=rule["penalty"],
                inline=True
            )

            embed.add_field(
                name="Steward Action",
                value=(
                    "Select **Post Result** to publish "
                    "this recommendation."
                ),
                inline=False
            )

            embed.set_footer(
                text=(
                    "Recommendation only • "
                    "Final decision remains with LRS stewards"
                )
            )

            await interaction.response.send_message(
                embed=embed,
                view=PostResultView(
                    rule["name"],
                    rule["points"],
                    rule["penalty"]
                ),
                ephemeral=True
            )

            return

        # Time-based offence
        embed = discord.Embed(
            title="⚖️ LRS PENALTY RECOMMENDATION",
            description=(
                "Review the recommended penalty below."
            )
        )

        embed.add_field(
            name="Offence",
            value=rule["name"],
            inline=False
        )

        embed.add_field(
            name="Licence Points",
            value=points_text,
            inline=True
        )

        embed.add_field(
            name="Additional Penalty",
            value=format_penalty(
                rule["penalty"]
            ),
            inline=True
        )

        embed.add_field(
            name="Steward Action",
            value=(
                "Choose a penalty, edit it if necessary, "
                "then select **Post Result**."
            ),
            inline=False
        )

        embed.set_footer(
            text=(
                "Recommendation only • "
                "Final decision remains with LRS stewards"
            )
        )

        await interaction.response.send_message(
            embed=embed,
            view=PenaltyEditView(
                offence_name=rule["name"],
                points=rule["points"],
                current_penalty=rule["penalty"],
                options=rule["options"]
            ),
            ephemeral=True
        )

    @discord.ui.button(
        label="Avoidable Collision",
        style=discord.ButtonStyle.primary
    )
    async def collision(
        self,
        interaction,
        button
    ):

        await interaction.response.send_message(
            "Select the observed damage level:",
            view=CollisionView(),
            ephemeral=True
        )

    @discord.ui.button(
        label="Quali Block",
        style=discord.ButtonStyle.danger
    )
    async def quali(
        self,
        interaction,
        button
    ):

        await self.show_rule(
            interaction,
            "quali_block"
        )

    @discord.ui.button(
        label="Pit Entry / Exit Cut",
        style=discord.ButtonStyle.primary
    )
    async def pit(
        self,
        interaction,
        button
    ):

        await self.show_rule(
            interaction,
            "pit_cut"
        )

    @discord.ui.button(
        label="Track Reset",
        style=discord.ButtonStyle.danger
    )
    async def reset(
        self,
        interaction,
        button
    ):

        await self.show_rule(
            interaction,
            "track_reset"
        )



# ============================================================
# LRS F1 SETUP CENTRE
# ============================================================

SETUPS = {
    "australia": {"name":"Australia","flag":"🇦🇺","map":"melbourne","w":[50,15],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,3,1,22,43],"b":[58,100],"y":[29.5,29.5,20.5,20.5]},
    "china": {"name":"China","flag":"🇨🇳","map":"shanghai","w":[50,38],"t":[100,40],"g":["L","L","L","L"],"s":[41,41,4,1,21,45],"b":[56,100],"y":[29.5,29.5,21.0,21.0]},
    "japan": {"name":"Japan","flag":"🇯🇵","map":"suzuka","w":[50,20],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,3,1,22,41],"b":[56,100],"y":[29.5,29.5,26.0,26.0]},
    "bahrain": {"name":"Bahrain","flag":"🇧🇭","map":"bahrain","w":[50,37],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,13,11,20,40],"b":[57,100],"y":[27.0,27.0,20.5,20.5]},
    "saudi": {"name":"Saudi Arabia","flag":"🇸🇦","map":"jeddah","w":[50,0],"t":[100,30],"g":["L","L","L","L"],"s":[41,41,14,11,21,40],"b":[57,100],"y":[29.5,29.5,26.0,26.0]},
    "miami": {"name":"Miami","flag":"🇺🇸","map":"miami","w":[35,10],"t":[100,30],"g":["L","L","L","L"],"s":[41,41,6,2,20,40],"b":[57,100],"y":[29.5,29.5,23.0,23.0]},
    "imola": {"name":"Imola","flag":"🇮🇹","map":"imola","w":[50,30],"t":[100,20],"g":["L","L","L","L"],"s":[41,41,6,6,20,42],"b":[56,100],"y":[29.5,29.5,21.0,21.0]},
    "monaco": {"name":"Monaco","flag":"🇲🇨","map":"monaco","w":[50,50],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,6,2,20,41],"b":[57,100],"y":[23.5,23.5,21.0,21.0]},
    "barcelona": {"name":"Barcelona","flag":"🇪🇸","map":"catalunya","w":[50,32],"t":[100,20],"g":["L","L","L","L"],"s":[41,26,6,2,20,42],"b":[56,100],"y":[29.5,29.5,20.5,20.5]},
    "canada": {"name":"Canada","flag":"🇨🇦","map":"montreal","w":[41,6],"t":[100,30],"g":["L","L","L","L"],"s":[41,37,6,2,20,40],"b":[57,100],"y":[29.5,29.5,21.0,21.0]},
    "austria": {"name":"Austria","flag":"🇦🇹","map":"spielberg","w":[50,25],"t":[100,35],"g":["L","L","L","L"],"s":[41,41,7,2,20,44],"b":[57,100],"y":[29.5,29.5,21.0,21.0]},
    "silverstone": {"name":"Silverstone","flag":"🇬🇧","map":"silverstone","w":[32,0],"t":[100,20],"g":["L","L","L","L"],"s":[41,41,9,2,20,43],"b":[56,100],"y":[29.5,29.5,22.0,22.0]},
    "spa": {"name":"Spa","flag":"🇧🇪","map":"spa-francorchamps","w":[16,0],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,9,2,23,44],"b":[57,100],"y":[29.5,29.5,21.0,21.0]},
    "hungary": {"name":"Hungary","flag":"🇭🇺","map":"hungaroring","w":[50,50],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,7,2,20,41],"b":[56,100],"y":[29.5,29.5,21.0,21.0]},
    "zandvoort": {"name":"Zandvoort","flag":"🇳🇱","map":"zandvoort","w":[50,40],"t":[100,30],"g":["L","L","L","L"],"s":[41,41,2,2,20,44],"b":[55,100],"y":[27.5,27.5,26.0,26.0]},
    "monza": {"name":"Monza","flag":"🇮🇹","map":"monza","w":[16,6],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,8,2,20,42],"b":[56,100],"y":[29.5,29.5,26.0,26.0]},
    "baku": {"name":"Baku","flag":"🇦🇿","map":"baku","w":[40,10],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,5,2,20,41],"b":[57,100],"y":[29.5,29.5,22.0,22.0]},
    "singapore": {"name":"Singapore","flag":"🇸🇬","map":"singapore","w":[50,47],"t":[100,40],"g":["L","L","L","L"],"s":[41,41,5,2,20,45],"b":[56,100],"y":[29.5,29.5,22.0,22.0]},
    "texas": {"name":"Texas","flag":"🇺🇸","map":"austin","w":[50,34],"t":[100,20],"g":["L","L","L","L"],"s":[41,41,11,3,20,41],"b":[57,100],"y":[29.5,29.5,20.5,20.5]},
    "mexico": {"name":"Mexico","flag":"🇲🇽","map":"mexico-city","w":[50,22],"t":[100,25],"g":["L","L","0.02","L"],"s":[41,41,8,3,21,41],"b":[57,100],"y":[29.5,29.5,26.5,26.5]},
    "brazil": {"name":"Brazil","flag":"🇧🇷","map":"interlagos","w":[50,24],"t":[100,20],"g":["L","L","L","L"],"s":[41,41,9,6,20,41],"b":[56,100],"y":[29.5,29.5,21.0,21.0]},
    "vegas": {"name":"Las Vegas","flag":"🇺🇸","map":"las-vegas","w":[16,1],"t":[100,20],"g":["L","L","L","L"],"s":[41,41,9,2,20,40],"b":[56,100],"y":[28.5,28.5,25.0,25.0]},
    "qatar": {"name":"Qatar","flag":"🇶🇦","map":"losail","w":[50,26],"t":[100,25],"g":["L","L","L","L"],"s":[41,41,21,20,20,43],"b":[56,100],"y":[29.5,29.5,25.0,25.0]},
    "abu_dhabi": {"name":"Abu Dhabi","flag":"🇦🇪","map":"yas-marina","w":[50,25],"t":[100,20],"g":["L","L","L","L"],"s":[41,41,9,10,20,40],"b":[56,100],"y":[29.5,29.5,20.5,20.5]},
}

# Optional banner URL. Upload your final LRS banner somewhere Discord can access
# and set LRS_SETUP_BANNER_URL in your host environment.
LRS_SETUP_BANNER_URL = os.getenv("LRS_SETUP_BANNER_URL", "")

def build_setup_embed(data):
    e = discord.Embed(
        title=f'{data["flag"]} {data["name"].upper()} — RACE SETUP',
        description="🏁 **LRS F1 SETUP CENTRE**",
        colour=discord.Colour.gold()
    )
    e.add_field(name="🪽 Aerodynamics",
                value=f'Front Wing: **{data["w"][0]}**\nRear Wing: **{data["w"][1]}**', inline=True)
    e.add_field(name="⚙️ Transmission",
                value=f'On-Throttle: **{data["t"][0]}%**\nOff-Throttle: **{data["t"][1]}%**', inline=True)
    e.add_field(name="📐 Suspension Geometry",
                value=(f'Front Camber: **{data["g"][0]}**\nRear Camber: **{data["g"][1]}**\n'
                       f'Front Toe: **{data["g"][2]}**\nRear Toe: **{data["g"][3]}**'), inline=False)
    e.add_field(name="🔧 Suspension",
                value=(f'Front Suspension: **{data["s"][0]}**\nRear Suspension: **{data["s"][1]}**\n'
                       f'Front Anti-Roll Bar: **{data["s"][2]}**\nRear Anti-Roll Bar: **{data["s"][3]}**\n'
                       f'Front Ride Height: **{data["s"][4]}**\nRear Ride Height: **{data["s"][5]}**'), inline=True)
    e.add_field(name="🛑 Brakes",
                value=f'Front Brake Bias: **{data["b"][0]}%**\nBrake Pressure: **{data["b"][1]}%**', inline=True)
    e.add_field(name="🛞 Tyres",
                value=(f'Front Left: **{data["y"][0]:.1f} PSI**\nFront Right: **{data["y"][1]:.1f} PSI**\n'
                       f'Rear Left: **{data["y"][2]:.1f} PSI**\nRear Right: **{data["y"][3]:.1f} PSI**'), inline=False)
    e.set_footer(text="🔒 This setup is private and only visible to you • Legends Racing Series")
    return e

class SetupTrackSelect(discord.ui.Select):
    def __init__(self):
        opts = [
            discord.SelectOption(label=v["name"], value=k, emoji=v["flag"], description="Race Setup")
            for k, v in SETUPS.items()
        ]
        super().__init__(
            placeholder="🏁 Choose a circuit...",
            min_values=1, max_values=1, options=opts,
            custom_id="lrs_combined_setup_track"
        )

    async def callback(self, interaction: discord.Interaction):
        data = SETUPS[self.values[0]]
        embed = build_setup_embed(data)
        # Use a public SVG->PNG proxy URL for the circuit outline.
        raw = f"https://raw.githubusercontent.com/julesr0y/f1-circuits-svg/refs/heads/main/circuits/minimal/white-outline/{data['map']}.svg"
        embed.set_image(url="https://images.weserv.nl/?url=" + urllib.parse.quote(raw, safe="") + "&w=900&h=500&fit=contain&output=png")
        await interaction.response.send_message(embed=embed, ephemeral=True)

class SetupCentreView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(SetupTrackSelect())

def setup_panel_embed():
    e = discord.Embed(
        title="🏆 LRS F1 SETUP CENTRE",
        description=(
            "### 🏎️ OPTIMISED RACE SETUPS\n"
            "**BUILT FOR PERFORMANCE**\n\n"
            "🏁 Select a circuit below to view the recommended **RACE** setup.\n"
            "🔒 Your selected setup will only be visible to you.\n\n"
            "**TESTED • BALANCED • CONSISTENT • FAST**"
        ),
        colour=discord.Colour.gold()
    )
    if LRS_SETUP_BANNER_URL:
        e.set_image(url=LRS_SETUP_BANNER_URL)
    e.set_footer(text="LRS — LEGENDS RACING SERIES")
    return e

@bot.tree.command(name="postsetup", description="Post the LRS F1 Setup Centre panel")
@app_commands.checks.has_permissions(manage_guild=True)
async def postsetup(interaction: discord.Interaction):
    await interaction.response.send_message("✅ LRS F1 Setup Centre posted.", ephemeral=True)
    await interaction.channel.send(embed=setup_panel_embed(), view=SetupCentreView())



# ============================================================
# GUILD
# ============================================================

GUILD_ID = 1260603938592260096

GUILD = discord.Object(
    id=GUILD_ID
)


# ============================================================
# BOT READY
# ============================================================

@bot.event
async def on_ready():

    bot.add_view(SetupCentreView())

    try:

        bot.tree.copy_global_to(guild=GUILD)

        synced = await bot.tree.sync(
            guild=GUILD
        )

        print(
            f"Synced {len(synced)} command(s) "
            f"to guild {GUILD_ID}"
        )

    except Exception as e:

        print(
            f"Guild command sync failed: {e}"
        )

    print(
        f"Logged in as {bot.user} "
        f"({bot.user.id})"
    )


# ============================================================
# RACE DIRECTOR APP — AUTOMATIC STEWARD PANEL
# ============================================================

@bot.event
async def on_message(message: discord.Message):
    """Automatically post the LRS Steward Assistant when RaceDirectorAPP
    calls the stewards after a defence has been submitted.
    """

    if message.author == bot.user:
        return

    # Diagnostic output for RaceDirectorAPP/webhook messages.
    # This helps identify whether Discord is sending plain text or embeds.
    if is_race_director_sender(message) or message.webhook_id is not None:
        preview = get_message_search_text(message).replace("\n", " | ")[:500]
        print(
            "[RaceDirector detection] "
            f"author={message.author} "
            f"webhook_id={message.webhook_id} "
            f"content_length={len(message.content or '')} "
            f"embeds={len(message.embeds)} "
            f"text={preview!r}"
        )

    if is_race_director_steward_call(message):
        print(
            f"[RaceDirector detection] MATCHED steward call in "
            f"channel {message.channel.id}"
        )

        embed = discord.Embed(
            title="🏁 LRS STEWARD BOT — CASE READY",
            description=(
                "🚨 **Stewards have been called to review this case.**\n\n"
                "The defence has been submitted and the case is ready "
                "for steward review.\n\n"
                "Review the full incident evidence, then use the controls "
                "below to prepare your recommendation."
            )
        )

        embed.add_field(
            name="Steward Recommendation",
            value=(
                "**My Recommendation for the Following Incident is:**\n"
                "Select the offence below to begin the assessment."
            ),
            inline=False
        )

        embed.add_field(
            name="Available Assessments",
            value=(
                "💥 **Avoidable Collision**\n"
                "🚫 **Quali Block**\n"
                "🛞 **Pit Entry / Exit Cut**\n"
                "🔄 **Track Reset**"
            ),
            inline=False
        )

        embed.set_footer(
            text="LRS Steward Bot • Final decision remains with LRS stewards"
        )

        try:
            await message.channel.send(
                embed=embed,
                view=OffenceView()
            )

            print(
                f"[RaceDirector detection] Steward panel posted in "
                f"channel {message.channel.id}"
            )

        except discord.Forbidden:
            print(
                f"[RaceDirector detection] Missing permission to post in "
                f"channel {message.channel.id}"
            )

        except Exception as e:
            print(
                f"[RaceDirector detection] Error posting steward panel: {e}"
            )

    await bot.process_commands(message)


# ============================================================
# /STEWARD
# ============================================================

@bot.tree.command(
    name="steward",
    description="Open the LRS Steward Assistant",
    guild=GUILD
)
@app_commands.describe(
    action="Choose the steward assistant function"
)
@app_commands.choices(
    action=[
        app_commands.Choice(
            name="Penalty Assistant",
            value="penalty"
        ),
        app_commands.Choice(
            name="Show LRS Penalties",
            value="rules"
        )
    ]
)
async def steward(
    interaction: discord.Interaction,
    action: app_commands.Choice[str]
):

    if action.value == "penalty":

        embed = discord.Embed(
            title="🏁 LRS Steward Assistant",
            description=(
                "Select the offence you want to assess."
            )
        )

        embed.set_footer(
            text=(
                "AI assistance only • Final decision "
                "remains with LRS stewards"
            )
        )

        await interaction.response.send_message(
            embed=embed,
            view=OffenceView(),
            ephemeral=True
        )

    else:

        lines = []

        for rule in PENALTIES.values():

            points = format_points(
                rule["points"]
            )

            if rule["options"]:

                penalty = " / ".join(
                    f"{value}s"
                    for value in rule["options"]
                )

            else:

                penalty = format_penalty(
                    rule["penalty"]
                )

            lines.append(
                f"**{rule['name']}** — "
                f"{points} + {penalty}"
            )

        await interaction.response.send_message(
            "\n".join(lines),
            ephemeral=True
        )


# ============================================================
# START BOT
# ============================================================

bot.run(TOKEN)