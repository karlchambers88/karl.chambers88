LRS COMBINED STEWARD + F1 SETUP BOT

This is your existing Steward Bot with the F1 Setup Centre incorporated.

1. Keep using the SAME DISCORD_TOKEN as the current Steward Bot.
2. Install:
   pip install -r requirements.txt
3. Run:
   py bot.py
4. In Discord use /postsetup once in the channel where you want the Setup Centre.
5. Drivers select a circuit. Their setup response is ephemeral/private.

The Steward/RaceDirector system remains in the same bot.py.

BANNER:
LRS_Setup_Centre_Banner.png is included.
Discord embeds need an internet-accessible image URL. Upload the banner to a stable public location,
then set LRS_SETUP_BANNER_URL to that direct image URL. If unset, the gold panel still works.

There are no Wet Setup or Time Trial controls.
